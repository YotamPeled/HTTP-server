#!/bin/bash

java ./Sources/Main