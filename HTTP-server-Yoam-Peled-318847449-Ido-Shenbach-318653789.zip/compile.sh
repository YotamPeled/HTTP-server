#!/bin/bash

javac ./Sources/Main.java