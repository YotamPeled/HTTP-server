public enum eRequestType {
    GET,
    POST,
    HEAD,
    TRACE,
    // not implemented
    PUT,
    DELETE,
    CONNECT,
    OPTIONS,
    PATCH
}
