#!/bin/bash

java Main