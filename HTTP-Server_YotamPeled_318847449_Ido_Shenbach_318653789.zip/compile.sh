#!/bin/bash

javac Main.java